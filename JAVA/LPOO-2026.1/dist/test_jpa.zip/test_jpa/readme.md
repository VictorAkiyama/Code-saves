[![Build Status](https://travis-ci.org/RutledgePaulV/test_jpa.svg?branch=develop)](https://travis-ci.org/RutledgePaulV/test_jpa)
[![Coverage Status](https://coveralls.io/repos/github/RutledgePaulV/test_jpa/badge.svg?branch=develop)](https://coveralls.io/github/RutledgePaulV/test_jpa?branch=develop)
[![Maven Central](https://maven-badges.herokuapp.com/maven-central/com.github.rutledgepaulv/test_jpa/badge.svg)](https://maven-badges.herokuapp.com/maven-central/com.github.rutledgepaulv/test_jpa)





Release Versions
```xml
<dependencies>
    <dependency>
        <groupId>br.edu.ifpr</groupId>
        <artifactId>test_jpa</artifactId>
        <version><!-- Not yet released --></version>
    </dependency>
</dependencies>
```

Snapshot Versions
```xml
<dependencies>
    <dependency>
        <groupId>br.edu.ifpr</groupId>
        <artifactId>test_jpa</artifactId>
        <version>0.0.1-SNAPSHOT</version>
    </dependency>
</dependencies>

<repositories>
    <repository>
        <id>ossrh</id>
        <name>Repository for snapshots</name>
        <url>https://oss.sonatype.org/content/repositories/snapshots</url>
        <snapshots>
            <enabled>true</enabled>
        </snapshots>
    </repository>
</repositories>
```


This project is licensed under [MIT license](http://opensource.org/licenses/MIT).
