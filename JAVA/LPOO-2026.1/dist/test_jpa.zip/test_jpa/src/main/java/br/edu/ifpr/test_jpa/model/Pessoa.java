package br.edu.ifpr.test_jpa.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString

@Entity
@Table(name = "PESSOA")
public class Pessoa {

   //CHAVE PRIMÁRIA
   @Id
   //EQUIVALENTE AO COMANDO AUTOINCREMENT DO BANCO DE DADOS
   @GeneratedValue(strategy = GenerationType.AUTO)
   private int id;

   //NOMEIA A COLUNA COMO "NOME_PESSOA" E COM O ATRIBUTO NOT NULL
   @Column(name = "NOME_PESSOA", nullable = false)
   private String nomePessoa;
   
   @Column(name = "IDADE", columnDefinition = "0", nullable = false)
   private int idade;
}