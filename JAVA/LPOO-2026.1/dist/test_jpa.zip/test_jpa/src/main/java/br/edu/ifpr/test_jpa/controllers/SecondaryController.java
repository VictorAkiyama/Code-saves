package br.edu.ifpr.test_jpa.controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import br.edu.ifpr.test_jpa.dao.DAO;
import br.edu.ifpr.test_jpa.main.App;
import br.edu.ifpr.test_jpa.model.Pessoa;
import br.edu.ifpr.test_jpa.util.Alerts;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;

public class SecondaryController implements Initializable{
	
	DAO<Pessoa> dao = DAO.getInstance(); //OBJETO SINGLETON
	
	@FXML private Button btVoltar;
	
	@FXML private TableView<Pessoa> tabelaDeRegistros;
    @FXML private TableColumn<Pessoa, Integer> ID;
    @FXML private TableColumn<Pessoa, String> NOME_PESSOA;
    @FXML private TableColumn<Pessoa, Integer> IDADE;
    
    private List<Pessoa> listaPessoas = new ArrayList<Pessoa>();
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        ID.setCellValueFactory(new PropertyValueFactory<Pessoa, Integer>("id"));
        NOME_PESSOA.setCellValueFactory(new PropertyValueFactory<Pessoa, String>("nomePessoa"));
        IDADE.setCellValueFactory(new PropertyValueFactory<Pessoa, Integer>("idade"));
        
    }
    
    //UTILIZADO PARA MANDAR OS REGISTROS ENCONTRADOS PELO CONTROLLER DO PRIMARY PARA O CONTROLLER DO SECONDARY
    //PrimaryController.listaPessoas -> SecondaryController.listaPessoas
    public void setListaPessoas(List<Pessoa> listaPessoas) {
        this.listaPessoas = listaPessoas;
        
        // ATUALIZA A TABLEVIEW
        tabelaDeRegistros.getItems().clear();
        tabelaDeRegistros.getItems().setAll(listaPessoas);
    }
    
    //BOTÃO PARA VOLTAR PARA A PRIMEIRA VIEW
    @FXML
    private void switchToPrimary() throws IOException {
    	try {
    		App.setRoot("primary");
    	} catch (IOException e) {
			e.printStackTrace();
			Alerts.showAlerts("Erro", "Erro ao mudar de views", "Erro ao mudar da primeira view para a segunda view", AlertType.ERROR);
		}
    }
}