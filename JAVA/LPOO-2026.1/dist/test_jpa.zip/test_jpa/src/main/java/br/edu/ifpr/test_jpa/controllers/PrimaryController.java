package br.edu.ifpr.test_jpa.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import br.edu.ifpr.test_jpa.main.App;
import br.edu.ifpr.test_jpa.dao.DAO;
import br.edu.ifpr.test_jpa.model.Pessoa;
import br.edu.ifpr.test_jpa.util.Alerts;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class PrimaryController {
	
	DAO<Pessoa> dao = DAO.getInstance(); //OBJETO SINGLETON
	
	private List<Pessoa> listaPessoas = new ArrayList<Pessoa>();
	
	int numeroIdDigitado;
	
	/* CRIAÇÃO DO ID "campoPesquisar"*/
	@FXML
	private TextField campoPesquisar;
	
	/* A AÇÃO QUE OCORRE SE OS DADOS INCORRETOS FORAM INSERIDOS E CLICAR NO BOTÃO*/
	public void campoPesquisarDadosNaoValidos() {
		Alerts.showAlerts("Erro", "Tipo de informação incorreta", "Os dados inseridos pelo usuário são do tipo incorreto que o campo espera, tente novamente", AlertType.ERROR);
	}
	
	/* CRIAÇÃO DO ID "btPesquisar" FAZ A RELAÇÃO COM O COMPONENTE NO SCENE BUILDERCOM ESSE ID */
	@FXML
	private Button btPesquisar;
	
	/* A AÇÃO QUE O COMPONENTE COM ID "btPesquisar" FAZ AO SER CLICADO */
	@FXML
	public void btPesquisarPorID() {
		try {
	        this.numeroIdDigitado = Integer.parseInt(campoPesquisar.getText());
	    } catch (NumberFormatException e) {
	        campoPesquisarDadosNaoValidos();
	        return;
	    }
		
		dao.clear();
		Pessoa pessoa = dao.find(Pessoa.class, this.numeroIdDigitado);
		if (pessoa == null) {
			btPesquisarNaoEncontrouRegistro();
		}
		else {
			try {
				//ADICIONA O REGISTRO ENCONTRADO E COLOCA NA LISTA
				//É PARA QUE NÃO HAJA SISTEMAS TÃO DIFERENTES ENTRE A PESQUISA POR ID DE UM ÚNICO REGISTRO
				//E A PESQUISA POR VÁRIOS REGISTROS, SEJA POR NOME OU O QUE SEJA
				this.listaPessoas.add(pessoa);
				switchToSecondary(listaPessoas);
			} catch (IOException e) {
				e.printStackTrace();
				Alerts.showAlerts("Erro", "Erro ao mudar de views", "Erro ao mudar da primeira view para a segunda view", AlertType.ERROR);
			}
		}
	}
	
	/* A AÇÃO QUE OCORRE SE NÃO FOI ENCONTRADO ALGUM REGISTRO COM O ID*/
	public void btPesquisarNaoEncontrouRegistro() {
		Alerts.showAlerts("Atenção", "Registro não encontrado", "Nenhum registro com o ID digitado foi encontrado", AlertType.WARNING);
	}
	
    private void switchToSecondary(List<Pessoa> listaPessoas) throws IOException {
    	FXMLLoader loader = new FXMLLoader(App.class.getResource("/fxml/secondary.fxml"));
        Parent root = loader.load();

        // PEGA O CONTROLLER DA SEGUNDA TELA
        SecondaryController controller = loader.getController();

        // ENVIA O DADO PARA O CONTROLLER DA SEGUNDA TELA
        controller.setListaPessoas(listaPessoas);

        Stage stage = (Stage) campoPesquisar.getScene().getWindow();
        stage.getScene().setRoot(root);
    }
}