package br.edu.ifpr.test_jpa.dao;

import java.util.List;

import br.edu.ifpr.test_jpa.model.Pessoa;

public class PessoaDAO extends DAO<Pessoa>{
	
	public Pessoa findPessoa (int id) {
		Pessoa pessoa;
		try {
			pessoa = em.find(Pessoa.class, id);
			return pessoa;
		}catch (Exception e) {
			return null;
		}
	}
	
	public List<Pessoa> findAll(){
		List<Pessoa> pessoas;
		try {
			pessoas = em.createQuery("SELECT s FROM Pessoa s", Pessoa.class).getResultList();
			return pessoas;
		}catch (Exception e) {
			return null;
		}
	}
}