package br.edu.ifpr.BularioApp.controllers;

import java.io.IOException;

import br.edu.ifpr.BularioApp.main.App;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class PaginaPrincipalController {

   @FXML
   private Button BotaoInserirRemedios;
   
   @FXML
   private Button BotaoListaDeRemedios;
   
   @FXML
   private void switchToListaDeRemedios() throws IOException {
      try {
         App.setRoot("ListaDeRemedios");
      } catch (IOException e) {
         e.printStackTrace();
         System.out.println("Erro ao mudar da view 'PaginaPrincipal' para a view 'ListaDeRemedios'");
      }
   }
   
   @FXML
   private void switchToInserirRemedio() throws IOException {
      try {
         App.setRoot("InserirRemedio");
      } catch (IOException e) {
         e.printStackTrace();
         System.out.println("Erro ao mudar da view 'PaginaPrincipal' para a view 'InserirRemedio'");
      }
   }
}