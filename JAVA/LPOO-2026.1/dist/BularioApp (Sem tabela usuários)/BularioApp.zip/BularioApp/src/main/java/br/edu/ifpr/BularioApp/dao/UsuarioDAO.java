package br.edu.ifpr.BularioApp.dao;

import br.edu.ifpr.BularioApp.model.Usuario;

public class UsuarioDAO extends DAO<Usuario> {
}