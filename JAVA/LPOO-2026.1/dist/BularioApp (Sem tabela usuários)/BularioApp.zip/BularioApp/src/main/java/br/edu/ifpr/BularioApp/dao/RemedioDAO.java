package br.edu.ifpr.BularioApp.dao;

import java.util.List;

import br.edu.ifpr.BularioApp.model.PublicoAlvo;
import br.edu.ifpr.BularioApp.model.Remedio;
import jakarta.persistence.Query;
import jakarta.persistence.TypedQuery;

public class RemedioDAO extends DAO<Remedio> {
	public List<Remedio> findByName(String name) {
		List<Remedio> remedios;
		try {
		    Query query = em.createQuery("SELECT r FROM Remedio r LEFT JOIN FETCH r.prescricao WHERE r.nome LIKE :name",Remedio.class);
		    query.setParameter("name", "%"+name+"%");
		    remedios = query.getResultList();
		    return remedios;
		}catch (Exception e) {
			return null;
		}
	}
	
	public Remedio FindByID(Remedio remedio) {
	   int idRemedio = remedio.getId();
	   Remedio entidadeRemedioComID;
	   try {
	      TypedQuery<Remedio> query = em.createQuery("SELECT r FROM Remedio r WHERE r.id = :idRemedio", Remedio.class);
	      query.setParameter("idRemedio", idRemedio);
	      entidadeRemedioComID = query.getSingleResult();
	      return entidadeRemedioComID;
	   } catch (Exception e) {
         e.printStackTrace();
         return null;
      }
	}
	
	@Override
	public void save(Remedio remedio) {
		try {
           em.getTransaction().begin();
           em.persist(remedio);
           em.getTransaction().commit();
           System.out.println("Remedio salvo com sucesso.");
	    } catch (Exception e) {
	       em.getTransaction().rollback();
	       throw new RuntimeException("Erro ao salvar o remedio", e);
	    }
	}
	
	@Override
	public void delete(Remedio remedio) {
      try {
         em.getTransaction().begin();
         em.remove(remedio);
         em.getTransaction().commit();
         System.out.println("Remedio excluido com sucesso.");
      } catch (Exception e) {
         em.getTransaction().rollback();
         throw new RuntimeException("Erro ao excluir o remedio", e);
      }
   }
}