package br.edu.ifpr.BularioApp.dao;

import br.edu.ifpr.BularioApp.model.Tarja;
import jakarta.persistence.TypedQuery;

public class TarjaDAO extends DAO<Tarja>{

   // PROCURA POR ENTIDADE TARJA COM CERTO NOME
   public Tarja findByName(String nome) {
      Tarja entidadeTarja;
      try {
         TypedQuery<Tarja> query = em.createQuery("SELECT t " + "FROM Tarja t " + "WHERE t.nome LIKE :nome", Tarja.class);
         query.setParameter("nome", "%"+nome+"%");
         entidadeTarja = query.getSingleResult();
         return entidadeTarja;
      } catch (Exception e) {
         e.printStackTrace();
         return null;
      }
   }
   
   @Override
   public void save(Tarja tarja) {
      try {
           em.getTransaction().begin();
           em.persist(tarja);
           em.getTransaction().commit();
           System.out.println("Tarja salva com sucesso.");
       } catch (Exception e) {
          em.getTransaction().rollback();
          throw new RuntimeException("Erro ao salvar a tarja", e);
       }
   }
}
