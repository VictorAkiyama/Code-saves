module br.edu.ifpr.BularioApp.main {
    requires javafx.controls;
    requires javafx.fxml;
    requires jakarta.persistence;
    requires lombok;
    requires org.hibernate.orm.core;
	requires javafx.base;
	requires javafx.graphics;
	requires org.apache.pdfbox;
	requires javafx.swing;

    opens br.edu.ifpr.BularioApp.main to javafx.fxml;
    opens br.edu.ifpr.BularioApp.controllers to javafx.fxml;
    opens br.edu.ifpr.BularioApp.model;
    exports br.edu.ifpr.BularioApp.main;
}
