package br.edu.ifpr.BularioApp.dao;

import java.util.ArrayList;
import java.util.List;

import br.edu.ifpr.BularioApp.model.Empresa;
import jakarta.persistence.Query;

public class EmpresaDAO extends DAO<Empresa> {
   public List<Empresa> findAll() {
      List<Empresa> entidadesEmpresa;
      try {
         Query query = em.createQuery("SELECT e FROM Empresa e", Empresa.class);
         entidadesEmpresa = query.getResultList();
         return entidadesEmpresa;
      } catch (Exception e) {
         e.printStackTrace();
         return new ArrayList<>();
      }
   }
   
   public Empresa findByID(int id) {
      return new Empresa();
   }
}
