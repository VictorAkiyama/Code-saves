package br.edu.ifpr.BularioApp.controllers;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import br.edu.ifpr.BularioApp.dao.EmpresaDAO;
import br.edu.ifpr.BularioApp.dao.PrescricaoDAO;
import br.edu.ifpr.BularioApp.dao.PublicoAlvoDAO;
import br.edu.ifpr.BularioApp.dao.RemedioDAO;
import br.edu.ifpr.BularioApp.dao.RemediosPublicoAlvoDAO;
import br.edu.ifpr.BularioApp.dao.TarjaDAO;
import br.edu.ifpr.BularioApp.main.App;
import br.edu.ifpr.BularioApp.model.Empresa;
import br.edu.ifpr.BularioApp.model.Prescricao;
import br.edu.ifpr.BularioApp.model.PublicoAlvo;
import br.edu.ifpr.BularioApp.model.Remedio;
import br.edu.ifpr.BularioApp.model.RemediosPublicoAlvo;
import br.edu.ifpr.BularioApp.model.Substancia;
import br.edu.ifpr.BularioApp.model.Tarja;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;
import javafx.scene.text.Text;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.util.StringConverter;

public class InserirRemedioController implements Initializable {
	
	RemedioDAO rdao = new RemedioDAO(); //OBJETO SINGLETON
	PublicoAlvoDAO padao = new PublicoAlvoDAO(); // OBJETO SINGLETON
	RemediosPublicoAlvoDAO rpadao = new RemediosPublicoAlvoDAO(); // OBJETO SINGLETON
	PrescricaoDAO pdao = new PrescricaoDAO(); // OBJETO SINGLETON
	TarjaDAO tdao = new TarjaDAO(); // OBJETO SINGLETON
	EmpresaDAO empdao = new EmpresaDAO(); // OBJETO SINGLETON
	
	private Remedio remedio = new Remedio(); // UTILIZADO PARA COLOCAR AS INFORMAÇÕES DIGITADAS PELO USUÁRIO E SALVAR O REMEDIO
	private Prescricao prescricao = new Prescricao(); // UTILIZADO PARA COLOCAR AS INFORMAÇÕES NA PRESCRIÇÃO A SER SALVA
	private Substancia substancia = new Substancia(); // UTILIZADO PARA COLOCAR AS INFORMAÇÕES NA SUBSTÂNCIA A SER SALVA
	private Tarja tarja = new Tarja(); // UTILIZADO PARA COLOCAR AS INFORMAÇÕES NA TARJA A SER SALVA
	private List<Remedio> listaRemediosTarja = new ArrayList<Remedio>(); // UTILIZADO PARA COLOCAR O REMÉDIO PARA SER SALVA JUNTO COM A TARJA
	
	@FXML
	private TextField campoNomeRemedio;
	@FXML
	private ChoiceBox<String> choiceboxTipoRemedio;
	@FXML
	private Button botaoEscolherBula;
	@FXML
	private Text textBula;
	@FXML
	private CheckBox publicoAlvoCriancas;
	@FXML
	private CheckBox publicoAlvoAdultos;
	@FXML
	private CheckBox publicoAlvoIdosos;
	@FXML
	private CheckBox publicoAlvoGestantes;
	@FXML
	private TextField campoRestricaoPrescricao;
	@FXML
	private TextField campoContraIndicacoesPrescricao;
	@FXML
	private TextField campoEfeitosPrescricao;
	@FXML
	private TextField campoNomeSubstancia;
	@FXML
	private TextField campoTipoSubstancia;
	@FXML
	private ChoiceBox<String> choiceboxTarja;
	@FXML
	private TextField campoValidadePrescricao;
	@FXML
	private TextField campoConservacaoPrescricao;
	@FXML
	private ComboBox<Empresa> comboboxSelecionarEmpresa;
	@FXML
	private TextField campoCNPJempresa;
	@FXML
	private TextField campoCidadeEmpresa;
	@FXML
	private TextField campoEstadoEmpresa;
	@FXML
	private Button botaoSalvar;
	
	@FXML
	private Label mensagemResultadoSalvarRemedio;
	
	public String nomeRemedioDigitado; // GUARDA O NOME DO REMÉDIO DIGITADO
	public String tipoRemedioSelecionado; // GUARDA O TIPO
	public String caminhoPDFBula; // GUARDA O CAMINHO DA BULA
	public String restricaoDigitada; // GUARDA A RESTRIÇÃO DA PRESCRIÇÃO
	public String contraIndicacaoDigitada; // GUARDA A CONTRA INDICAÇÃO DA PRESCRIÇÃO 
	public String efeitosDigitado; // GUARDA OS EFEITOS DA PRESCRIÇÃO
	public String validadeDigitada; // GUARDA A VALIDADE DA PRESCRIÇÃO
	public String conservacaoDigitada; // GUARDA A CONSERVAÇÃO DA PRESCRIÇÃO
	public String nomeSubstanciaDigitada; // GUARDA O NOME DA SUBSTÂNCIA DIGITADA
	public String tipoSubstanciaDigitada; // GUARDA O TIPO DA SUBSTÃNCIA DIGITADA
	public String tarjaSelecionada; // GUARDA A TARJA SELECIONADA
	private ObservableList<Empresa> empresasOriginais; // GUARDA TODAS AS EMPRESAS
	
	@Override
   public void initialize(URL url, ResourceBundle rb) {
		choiceboxTipoRemedio.getItems().addAll("G", "S"); // ADICIONANDO AS OPÇÕES PARA A CHOICEBOX TIPO REMÉDIO
		choiceboxTarja.getItems().addAll("Sem tarja", "Vermelha", "Preta"); // ADICIONANDO AS OPÇÕES PARA A CHOICEBOX TARJA
		
		empresasOriginais = FXCollections.observableArrayList();
	   empresasOriginais.addAll(empdao.findAll());

	   comboboxSelecionarEmpresa.setItems(empresasOriginais);

	   comboboxSelecionarEmpresa.setEditable(true);

	   comboboxSelecionarEmpresa.setConverter(new StringConverter<Empresa>() {

	       @Override
	       public String toString(Empresa empresa) {
	           return empresa == null ? "" : empresa.getNome();
	       }

	       @Override
	       public Empresa fromString(String nome) {

	           for (Empresa empresa : empresasOriginais) {
	               if (empresa.getNome().equalsIgnoreCase(nome)) {
	                   return empresa;
	               }
	           }

	           return null;
	       }
	   });
	   comboboxSelecionarEmpresa.getEditor().textProperty().addListener(
	       new ChangeListener<String>() {
	           @Override
	           public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
	               ObservableList<Empresa> empresasFiltradas = FXCollections.observableArrayList();

	               if (newValue == null || newValue.isEmpty()) {
	                   comboboxSelecionarEmpresa.setItems(empresasOriginais);
	               } else {
	                   for (Empresa empresa : empresasOriginais) {
	                       if (empresa.getNome().toLowerCase().contains(newValue.toLowerCase())) {
                            empresasFiltradas.add(empresa);	
                          }
	                   }
	                   comboboxSelecionarEmpresa.setItems(empresasFiltradas);
	               }
	               comboboxSelecionarEmpresa.show();
	           }
	       }
	   );
	   
	   comboboxSelecionarEmpresa.getSelectionModel().selectedItemProperty().addListener(
	       new ChangeListener<Empresa>() {

	           @Override
	           public void changed(ObservableValue<? extends Empresa> observable, Empresa oldValue, Empresa empresaSelecionada) {
	               if (empresaSelecionada != null) {
	                   campoCNPJempresa.setText(empresaSelecionada.getCnpj());
	                   campoCidadeEmpresa.setText(empresaSelecionada.getCidade().getNome());
	                   campoEstadoEmpresa.setText(empresaSelecionada.getCidade().getUf());
	               }
              }
          }
	   );
	}
	
	@FXML
	private void cadastrarMedicamento() throws IOException {
		 remedio = new Remedio(); // LIMPANDO O REMEDIO, PERMITINDO O USUÁRIO CRIAR MAIS UM REMÉDIO DEPOIS DE TER CRIADO UM
		 nomeRemedioDigitado = campoNomeRemedio.getText(); // PEGA O TEXTO DIGITADO NO CAMPO NOME
		 remedio.setNome(nomeRemedioDigitado); // COLOCANDO O TEXTO DIGITADO NO NOME DO REMÉDIO
		 
		 tipoRemedioSelecionado = choiceboxTipoRemedio.getValue(); // PEGA O TIPO
		 remedio.setTipo(tipoRemedioSelecionado); // COLOCANDO O TIPO
		 
		 remedio.setBula(caminhoPDFBula); // COLOCANDO PDF DA BULA
		 
		 Prescricao prescricao = new Prescricao(); // LIMPANDO A PRESCRICAO
		 
		 prescricao.setRemedio(remedio); // COLOCANDO O REMEDIO NA PRESCRICAO
		 
		 restricaoDigitada = campoRestricaoPrescricao.getText(); // PEGA O TEXTO DIGITADO NO CAMPO RESTRIÇÃO
		 prescricao.setRestricao(restricaoDigitada); // COLOCANDO O TEXTO DIGITADO NA RESTRIÇÃO DA PRESCRIÇÃO
		 
		 contraIndicacaoDigitada = campoContraIndicacoesPrescricao.getText(); // PEGA O TEXTO DIGITADO NO CAMPO CONTRA INDICAÇÕES
		 prescricao.setContraIndicacoes(contraIndicacaoDigitada); // COLOCANDO O TEXTO DIGITADO NA CONTRA INDICAÇÔES DA PRESCRIÇÃO
		 
		 efeitosDigitado = campoEfeitosPrescricao.getText(); // PEGA O TEXTO DIGITADO NO CAMPO EFEITOS
		 prescricao.setEfeitos(efeitosDigitado); // COLOCANDO O TEXTO DIGITADO NOS EFEITOS DA PRESCRIÇÃO
		 
		 validadeDigitada = campoValidadePrescricao.getText(); // PEGA O TEXTO DIGITADO NO CAMPO VALIDADE
		 prescricao.setValidade(validadeDigitada); // COLOCANDO O TEXTO DIGITADO NA VALIDADE DA PRESCRIÇÃO
		 
		 conservacaoDigitada = campoConservacaoPrescricao.getText(); // PEGA O TEXTO DIGITADO NO CAMPO CONSERVAÇÃO
		 prescricao.setConservacao(conservacaoDigitada); // COLOCANDO O TEXTO DIGITADO NA CONSERVAÇÃO DA PRESCRIÇÃO
		 
		 remedio.setPrescricao(prescricao); // COLOCANDO A PRESCRIÇÃO NO REMEDIO
		 
		 Substancia substancia = new Substancia(); // LIMPANDO A SUBSTÂNCIA
		 
		 substancia.setRemedio(remedio); // COLOCANDO O REMEDIO NA SUBTÂNCIA
		 
		 nomeSubstanciaDigitada = campoNomeSubstancia.getText(); // PEGA O TEXTO DIGITADO NO CAMPO NOME SUBSTÂNCIA
		 substancia.setNome(nomeSubstanciaDigitada); // COLOCANDO O TEXTO DIGITADO NO NOME DA SUBSTÂNCIA
		 
		 tipoSubstanciaDigitada = campoTipoSubstancia.getText(); // PEGA O TEXTO DIGITADO NO CAMPO TIPO SUBSTÂNCIA
		 substancia.setTipo(tipoSubstanciaDigitada); // COLOCANDO O TIPO DIGITADO NO TIPO DA SUBSTÂNCIA
		 
		 remedio.setSubstancia(substancia); // COLOCANDO A SUBSTÂNCIA NO REMÉDIO
		 
		 tarjaSelecionada = choiceboxTarja.getValue(); // PEGA O NOME DA TARJA SELECIONADA
		 tarja = tdao.findByName(tarjaSelecionada); // PROCURA E COLOCA A TARJA SELECIONADA PELO NOME
		 
		 listaRemediosTarja.add(remedio); // COLOCANDO O REMÉDIO NA LISTA
		 tarja.setRemedios(listaRemediosTarja); // COLOCANDO O REMÉDIO DA LISTA NA LISTA DA TARJA
		 
		 remedio.setTarja(tarja); // COLOCANDO A TARJA NO REMÉDIO
		 
		 Empresa empresaSelecionada = comboboxSelecionarEmpresa.getValue(); // PEGANDO A EMPRESA SELECIONADA
		 if (empresaSelecionada == null) { // VERIFICANDO SE É NULL
		    System.out.println("Nenhuma empresa selecionada");
		    mensagemResultadoSalvarRemedio.setVisible(true);
          mensagemResultadoSalvarRemedio.setText("Erro ao salvar o medicamento, tente novamente.");
          mensagemResultadoSalvarRemedio.setTextFill(Color.RED);
		    return;
		 }
		 
		 remedio.setEmpresa(empresaSelecionada); // COLOCANDO A EMPRESA NO REMÉDIO
		 
		 try {
			  	rdao.save(remedio); // SALVANDO O REMÉDIO, AUTOMATICAMENTE SALVA A PRESCRIÇÃO, SUBSTÂNCIA TAMBÉM
			  	tdao.save(tarja); // SALVANDO A TARJA
			  	mensagemResultadoSalvarRemedio.setVisible(true);
			 	mensagemResultadoSalvarRemedio.setText("Medicamento salvo com sucesso.");
			 	mensagemResultadoSalvarRemedio.setTextFill(Color.GREEN);
			 	
			 	// VERIFICANDO OS CHECKBOX
			 	if (publicoAlvoCriancas.isSelected()) {
			 		RemediosPublicoAlvo rpa1 = new RemediosPublicoAlvo();
			 		PublicoAlvo pa = new PublicoAlvo();
				 
			 		rpa1.setRemedio(remedio); // COLOCA O REMEDIO NO REMEDIOS PUBLICO ALVO
				 
			 		pa = padao.findByName("Crianças"); // PEGANDO O PUBLICO ALVO CRIANÇAS
			 		rpa1.setPublicoAlvo(pa); // COLOCA O PUBLICO ALVO NO REMEDIOS PUBLICO ALVO
			 		
			 		rpadao.save(rpa1); // SALVANDO O REMEDIOS PUBLICO ALVO
			 	}
			 	if (publicoAlvoAdultos.isSelected()) {
			 		RemediosPublicoAlvo rpa2 = new RemediosPublicoAlvo();
			 		PublicoAlvo pa = new PublicoAlvo();
			 		
			 		rpa2.setRemedio(remedio);
			 		
			 		pa = padao.findByName("Adultos"); // PEGANDO O PUBLICO ALVO ADULTOS
			 		rpa2.setPublicoAlvo(pa);
			 		
			 		rpadao.save(rpa2);
			 	}
			 	if (publicoAlvoIdosos.isSelected()) {
			 		RemediosPublicoAlvo rpa3 = new RemediosPublicoAlvo();
			 		PublicoAlvo pa = new PublicoAlvo();
			 		
			 		rpa3.setRemedio(remedio);
			 		
			 		pa = padao.findByName("Idosos"); // PEGANDO O PUBLICO ALVO IDOSOS
			 		rpa3.setPublicoAlvo(pa);
			 		
			 		rpadao.save(rpa3);
			 	}
			 	if (publicoAlvoGestantes.isSelected()) {
			 		RemediosPublicoAlvo rpa4 = new RemediosPublicoAlvo();
			 		PublicoAlvo pa = new PublicoAlvo();
			 		
			 		rpa4.setRemedio(remedio);
			 		
			 		pa = padao.findByName("Gestantes"); // PEGANDO O PUBLICO ALVO GESTANTES
			 		rpa4.setPublicoAlvo(pa);
			 		
			 		rpadao.save(rpa4);
			 	}
			 	
			 	//LIMPANDO VARIAVÉIS
			 	nomeRemedioDigitado = null; 
				tipoRemedioSelecionado = null;
				caminhoPDFBula = null;
				restricaoDigitada = null;
				contraIndicacaoDigitada = null;
			   efeitosDigitado = null;
			   validadeDigitada = null;
			   conservacaoDigitada= null;
			   nomeSubstanciaDigitada = null;
			   tipoSubstanciaDigitada = null;
				//LIMPANDO ELEMENTOS FXML
				textBula.setText("Nenhum arquivo escolhido");
		 } catch (Exception e) {	// SE DER ERRADO
		      e.printStackTrace();
			 	mensagemResultadoSalvarRemedio.setVisible(true);
			 	mensagemResultadoSalvarRemedio.setText("Erro ao salvar o medicamento, tente novamente.");
			 	mensagemResultadoSalvarRemedio.setTextFill(Color.RED);
		 }
	}
	
	@FXML
	private void escolherArquivoPDF() {
		FileChooser fileChooser = new FileChooser();

	    fileChooser.setTitle("Selecionar PDF");
	    fileChooser.getExtensionFilters().add(
	        new FileChooser.ExtensionFilter("Arquivos PDF", "*.pdf")
	    );

	    File arquivo = fileChooser.showOpenDialog(botaoEscolherBula.getScene().getWindow());
	    
	    caminhoPDFBula = arquivo.getAbsolutePath();

	    if (arquivo != null) {
	    	textBula.setText(caminhoPDFBula);
	        System.out.println("Nome do arquivo: " + arquivo.getName());
	        System.out.println("Caminho do arquivo: " + caminhoPDFBula);
	    }
	    else {
	    	textBula.setText("Nenhum arquivo escolhido");
	    }
	}
	
	@FXML
	private void switchToPaginaPrincipal() throws IOException {
       try {
  		  App.setRoot("PaginaPrincipal");
  	   } catch (IOException e) {
  	      e.printStackTrace();
          System.out.println("Erro ao mudar da view 'InserirRemedio' para a view 'PaginaPrincipal'");
       }
    }
}