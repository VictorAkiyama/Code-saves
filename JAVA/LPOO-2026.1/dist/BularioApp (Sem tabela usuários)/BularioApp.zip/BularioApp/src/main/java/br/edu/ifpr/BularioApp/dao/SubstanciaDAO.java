package br.edu.ifpr.BularioApp.dao;

import java.util.ArrayList;
import java.util.List;

import br.edu.ifpr.BularioApp.model.Remedio;
import br.edu.ifpr.BularioApp.model.Substancia;
import jakarta.persistence.Query;

public class SubstanciaDAO extends DAO<Substancia> {
	
	public List<Substancia> findByRelation(Remedio remedio) {
		int idRemedioSelecionado = remedio.getId();
		List<Substancia> entidadesSubstancia;
		try {
		    Query query = em.createQuery("SELECT s " + "FROM Substancia s, SubstanciaRemedio sr, Remedio r " +  
		    "WHERE sr.substancia.id=s.id AND sr.remedio.id = :idRemedioSelecionado",Substancia.class);
		    query.setParameter("idRemedioSelecionado", remedio.getId());
		    entidadesSubstancia = query.getResultList();
		    return entidadesSubstancia;
		}catch (Exception e) {
			e.printStackTrace();
	        return new ArrayList<>();
		}
	}
	
	@Override
   public void save(Substancia substancia) {
      try {
           em.getTransaction().begin();
           em.persist(substancia);
           em.getTransaction().commit();
           System.out.println("Prescricao salvo com sucesso.");
       } catch (Exception e) {
          em.getTransaction().rollback();
          throw new RuntimeException("Erro ao salvar a prescricao", e);
       }
   }
}
